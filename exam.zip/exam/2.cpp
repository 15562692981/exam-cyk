#include<iostream>

int main() {
	unsigned char byte = 0b10101010;
	unsigned char mask = 0b10000000;

	for (int i = 0; i < 8; i++) {
		unsigned char bit = (byte & mask) ? 1 : 0;
		std::cout << bit << "";
		mask >>= 1;
	}

	return 0;
}