#include<iostream>
#include<string>
#include<cctype>

int main() {
	std::string sentence;
	std::cout << "������һ��Ӣ�ģ� " << std::endl;
	std::getline(std::cin, sentence);

	bool capitalizeNext = true;
	for (size_t i = 0; i < sentence.length(); i++) {
		if (capitalizeNext && std::isalpha(sentence[i])) {
			sentence[i] = std::toupper(sentence[i]);
			capitalizeNext = false;
		}
		else if (std::isspace(sentence[i])) {
			capitalizeNext = true;
		}
	}
	std::cout << "����ĸ��д��ľ���Ϊ�� " << sentence << std::endl;

	return 0;
}